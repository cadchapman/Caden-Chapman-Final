let score = 0;
let clickValue = 1;

let clickButton;
let upgradeButton;

let upgradeCost = 10;

let clickAnim = 0;
let clickAnimSpeed = 0.2;

function setup() {
  createCanvas(500, 500);

  // --- Main click button ---
  clickButton = new Button("BOX", 200, 170);
  clickButton.width = 100;
  clickButton.height = 100;
  clickButton.fill = [200, 180, 255];
  clickButton.stroke = [80, 60, 150];
  clickButton.strokeWeight = 3;

  clickButton.onPressBegin = function () {
    score += clickValue;
    clickAnim = 1;    
  };

  // --- Upgrade button ---
  upgradeButton = new Button("BOX", 200, 350);
  upgradeButton.width = 100;
  upgradeButton.height = 100;
  upgradeButton.fill = [150, 230, 150];
  upgradeButton.stroke = [40, 90, 40];
  upgradeButton.strokeWeight = 3;

  upgradeButton.onPressBegin = function () {
    if (score >= upgradeCost) {
      score -= upgradeCost;
      clickValue++;
      upgradeCost = floor(upgradeCost * 1.75);
    }
  };
}

function draw() {
  background(30);

  // Main text
  fill(255);
  textSize(26);
  textAlign(CENTER, TOP);
  text("Score: " + score, width / 2, 20);

  // Upgrade info
  textSize(16);
  text(`Click Value: ${clickValue}`, 248, 280);
  text(`Cost: ${upgradeCost}`, 248, 460);

  textSize(18);
  text("UPGRADE", 248, 325);

  // Click button label
  text("CLICK", 248, 145);

  // --- Animation Code ---
  clickAnim = max(0, clickAnim - clickAnimSpeed);
  let scaleAmount = 1 - clickAnim * 0.2;

  
  push();
  translate(250, 220);      
  scale(scaleAmount);
  translate(-250, -220);    
  clickButton.update();
  clickButton.draw();
  pop();

  
  upgradeButton.update();
  upgradeButton.draw();
}